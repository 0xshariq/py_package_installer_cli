import claudeRoutes from './routes/claudeRoutes.js';

app.use("/api/claude", claudeRoutes);