
import configRoutes from "./routes/configRoutes";

app.use("/api/config", configRoutes);