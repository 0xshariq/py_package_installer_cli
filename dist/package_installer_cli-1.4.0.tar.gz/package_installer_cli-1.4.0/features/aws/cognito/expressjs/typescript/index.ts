
import awsCognitoRoutes from './routes/awsCognitoRoutes';

app.use("/api/cognito",awsCognitoRoutes)