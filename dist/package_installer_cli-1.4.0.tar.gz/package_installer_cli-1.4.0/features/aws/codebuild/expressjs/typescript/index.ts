
import codeBuildRoutes from './routes/codeBuildRoutes';

app.use("/api/codebuild",codeBuildRoutes)