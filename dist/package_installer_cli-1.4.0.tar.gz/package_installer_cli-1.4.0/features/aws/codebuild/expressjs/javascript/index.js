
import codeBuildRoutes from './routes/codeBuildRoutes.js';

app.use("/api/codebuild",codeBuildRoutes)