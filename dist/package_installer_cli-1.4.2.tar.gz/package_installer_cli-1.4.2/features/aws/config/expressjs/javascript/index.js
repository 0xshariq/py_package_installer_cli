
import configRoutes from "./routes/configRoutes.js";

app.use("/api/config", configRoutes);