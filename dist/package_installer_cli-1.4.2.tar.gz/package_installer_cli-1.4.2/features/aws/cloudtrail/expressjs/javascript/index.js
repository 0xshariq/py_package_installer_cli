
import cloudTrailRoutes from "./routes/awsCloudTrailRoutes.js";

app.use("/api/cloud-trail", cloudTrailRoutes);