
import codeDeployRoutes from './routes/codeDeployRoutes.js';

app.use("/api/codedeploy",codeDeployRoutes)