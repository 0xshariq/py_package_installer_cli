import openRouterkRoutes from './routes/openRouterkRoutes.js';

app.use("/api/open-router", openRouterkRoutes);