import grokRoutes from './routes/grokRoutes.js';

app.use("/api/grok", grokRoutes);